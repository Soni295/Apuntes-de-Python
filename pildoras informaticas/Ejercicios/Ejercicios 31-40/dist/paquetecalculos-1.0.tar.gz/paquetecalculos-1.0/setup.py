from setuptools import setup

setup(
  name="paquetecalculos",
  version="1.0",
  description="paquete de redondeo y potencia",
  author="Sion",#paquete, modulo
  packarges=["modulo2","modulo2.redondeo_potencia.Ejercicio037b"]
)